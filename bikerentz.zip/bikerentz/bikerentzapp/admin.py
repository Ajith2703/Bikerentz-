from django.contrib import admin
from bikerentzapp.models import bikes
# Register your models here.
admin.site.register(bikes)