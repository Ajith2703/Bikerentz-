from django.shortcuts import render, redirect
from bikerentzapp.models import user,admin,bikes,bookings,feedbacks
from django.contrib import messages
from django.db import connection
import os
from django.http import HttpResponse, Http404
from bikerentzproject import settings


def register(request):
    if request.method=='POST':
        users=user()
        users.Username=request.POST['uname']
        users.Name=request.POST['name']
        users.Contact=request.POST['contact']
        users.DOB=request.POST['dob']
        users.Age=request.POST['age']
        users.Address=request.POST['address']
        users.Email=request.POST['email1']
        users.Password=request.POST['password1']
        users.save()
        return redirect('home')
    return render(request,'register.html')

def session_required(view_func):
    def wrapper_func(request, *args, **kwargs):
        if 'username' not in request.session:
            return redirect('home')  # Redirect to home if session does not exist
        return view_func(request, *args, **kwargs)
    return wrapper_func

def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password2']
        # Try to fetch user details from the database
        try:
            data=user.objects.get(Username=username, Password=password)  # Match the form fields to your model
        except user.DoesNotExist:
            data=None
        if data is not None:
            # Set session information manually
            # request.session['email'] = data.Email
            request.session['username'] = data.Username  # Store the user ID in session
            return redirect('dashboard')  # Redirect to home page after login
        else:
            messages.error(request, 'Invalid credentials')
    return render(request, 'login.html')

def session_required1(view_func):
    def wrapper_func(request,*args,**kwargs):
        if 'username' not in request.session:
            return redirect('home')
        return view_func(request,*args,**kwargs)
    return wrapper_func

def admin_login(request):
    if request.method == "POST":
        username=request.POST['uname']
        password=request.POST['password3']
        try:
            data=admin.objects.get(Username=username,Password=password)
        except admin.DoesNotExist:
            data=None
        if data is not None:
            request.session['username']=data.Username
            # request.session['admin_id']=data.id
            return redirect('admin_dashboard')
        else:
            messages.error(request,'Invalid credentials')
    return render(request,'home.html')

@session_required
def user_home(request):
    if 'username' not in request.session:
        print("Session 'user_id' not found. Redirecting to login.")
        return redirect('login')  # Redirect to home if not authenticated
    print("Session username:", request.session['username']) # Print session data for debugging
    username = request.session['username']
    results1 = bookings.objects.filter(CustomerUsername=username)
    results2 = feedbacks.objects.filter(Username=username)
    value1 = len(results1)
    value2 = len(results2)
    return render(request,'dashboard.html',{'value1':value1,'value2':value2})

@session_required
def view_bikes(request):
    select_bikes=bikes.objects.all()
    return render(request,'viewbikes.html',{'select':select_bikes})

@session_required
def book_bikes(request,id):
    users=request.session['username']
    get_user=user.objects.get(Username=users)
    get_bike=bikes.objects.get(id=id)
    if request.method=="POST":
        book_bikes=bookings()
        # book_bikes.CustomerUsername = request.POST.get('uname')
        book_bikes.CustomerUsername = users
        book_bikes.CustomerName = request.POST.get('cname')
        book_bikes.CustomerContact = request.POST.get('ccontact')
        book_bikes.CustomerEmail = request.POST.get('cemail')
        book_bikes.CustomerAddress = request.POST.get('caddress')
        book_bikes.RentalDate = request.POST.get('rental-date')
        book_bikes.BikeName = request.POST.get('bname')
        book_bikes.Rent = request.POST.get('brent')
        book_bikes.Idproof = request.POST.get('Idproof')
        if len(request.FILES)!=0:
            book_bikes.Idfile = request.FILES.get('Idfile')
            book_bikes.save()
            return redirect('dashboard')
    else:
            return render(request,'bookbikes.html',{'get_user':get_user,'get_bike':get_bike})

@session_required
def my_bookings(request):
    users=request.session['username']
    results=bookings.objects.filter(CustomerUsername=users)
    return render(request,'mybookings.html',{'booking':results})

@session_required
def delete_booking(request,id):
    del_booking=bookings.objects.get(id=id)
    del_booking.delete()
    return render(request,'my_bookings')

@session_required
def post_feedback(request):
    users = request.session['username']
    get_bike=bookings.objects.all()
    if request.method == "POST":
        feedback=feedbacks()
        feedback.Username = users
        feedback.Bikename = request.POST.get('bike')
        feedback.Feedback = request.POST.get('feedback')
        feedback.save()
        return redirect('dashboard')
    return render(request,'postfeedback.html',{'getbike':get_bike})

@session_required
def my_feedback(request):
    users = request.session['username']
    get_feedback = feedbacks.objects.filter(Username=users)
    return render(request,'myfeedback.html',{'get_feedback':get_feedback})

@session_required
def user_profile(request):
    users=request.session['username']
    user_data=user.objects.get(Username=users)
    return render(request,'userprofile.html',{'user_data':user_data})

@session_required
def edit_userprofile(request,id):
    get_user=user.objects.get(id=id)
    if request.method=="POST":
        get_user.Contact = request.POST.get('contact')
        get_user.DOB = request.POST.get('dob')
        get_user.Age = request.POST.get('age')
        get_user.Address = request.POST.get('address')
        get_user.Email = request.POST.get('email1')
        get_user.Password = request.POST.get('password1')
        get_user.save()
        return redirect('user_profile')
    return render(request,'edituserprofile.html',{'getuser':get_user})

def logout_user(request):
    request.session.flush()
    return redirect('home')




@session_required1
def admin_home(request):
    if 'username' not in request.session:
        print("Session 'username' not found. Redirecting to login.")
        return redirect('home')
    print("Session username:", request.session['username'])
    result1 = user.objects.all()
    value1 = len(result1)
    result2 = bookings.objects.all()
    value2 = len(result2)
    cursor1 = connection.cursor()
    cursor1.execute("select * from bikerentzapp_bookings where bikerentzapp_bookings.BookingStatus='Accepted'")
    result3 = cursor1.fetchall()
    value3 = len(result3)
    cursor1.execute("select * from bikerentzapp_bookings where bikerentzapp_bookings.BookingStatus='Waiting'")
    result4 = cursor1.fetchall()
    value4 = len(result4)
    cursor1.execute("select * from bikerentzapp_bookings where bikerentzapp_bookings.BookingStatus='Rejected'")
    result5 = cursor1.fetchall()
    value5 = len(result5)
    cursor1.execute("select * from bikerentzapp_bookings where bikerentzapp_bookings.BookingStatus='Completed'")
    result6 = cursor1.fetchall()
    value6 = len(result6)
    result7 = bikes.objects.all()
    value7 = len(result7)
    result8 = feedbacks.objects.all()
    value8 = len(result8)
    return render(request,'admindashboard.html',{'value1':value1,'value2':value2,'value3':value3,'value4':value4,'value5':value5,'value6':value6,'value7':value7,'value8':value8})

@session_required1
def all_users(request):
    users=user.objects.all()
    return render(request,'allusers.html',{'getuser':users})

@session_required1
def delete_user(request,id):
    del_user=user.objects.get(id=id)
    del_user.delete()
    return redirect('all_users')

@session_required1
def add_bikes(request):
    if request.method == "POST":
        # if request.POST.get('Vehiclebrand') and request.POST.get('Vehicletype'):
        bike=bikes()
        bike.Vehiclename = request.POST.get('vname')
        bike.Vehiclebrand = request.POST.get('vbrand')
        bike.Vehicletype = request.POST.get('vtype')
        bike.Modelyear = request.POST.get('model')
        bike.Vehiclenumber = request.POST.get('vnum')
        bike.Insuranceupto = request.POST.get('insyear')
        bike.AmountPerDay = request.POST.get('vamt')
        bike.VehicleDescription = request.POST.get('vdesc')
        if len(request.FILES)!=0:
            bike.Vehicleimage = request.FILES.get('vimage')
            bike.save()
            return redirect('manage_bikes')
    else:
            return render(request,'addbikes.html')

@session_required1
def manage_bikes(request):
    view_bikes=bikes.objects.all()
    return render(request,'managebikes.html',{'view':view_bikes})

@session_required1
def edit_bikes(request,id):
    edit_bike=bikes.objects.get(id=id)
    if request.method=="POST":
        edit_bike.Vehiclename = request.POST.get('vname')
        edit_bike.Vehiclebrand = request.POST.get('vbrand')
        edit_bike.Vehicletype = request.POST.get('vtype')
        edit_bike.Modelyear = request.POST.get('model')
        edit_bike.Vehiclenumber = request.POST.get('vnum')
        edit_bike.Insuranceupto = request.POST.get('insyear')
        edit_bike.AmountPerDay = request.POST.get('vamt')
        edit_bike.VehicleDescription = request.POST.get('vdesc')
        if len(request.FILES) != 0:
            edit_bike.Vehicleimage = request.FILES.get('vimage')
            edit_bike.save()
            return redirect('manage_bikes')
    else:
        return render(request, 'editbikes.html',{'edit_bike':edit_bike})

@session_required1
def delete_bikes(request,id):
    del_bikes=bikes.objects.get(id=id)
    del_bikes.delete()
    return redirect('manage_bikes')

@session_required1
def all_bookings(request):
    cursor1=connection.cursor()
    cursor1.execute("select * from bikerentzapp_bookings where bikerentzapp_bookings.BookingStatus IS NULL")
    results1=cursor1.fetchall()
    return render(request,'newbookings.html',{'viewbookings':results1})

@session_required1
def download(request,path):
    file_path=os.path.join(settings.STATIC_ROOT,path)
    if os.path.exists(file_path):
        with open(file_path,'rb')as fh:
            response=HttpResponse(fh.read(),content_type="application/Idfile")
            response['Content-Disposition']='inline;filename'+os,path.basename(file_path)
            return response
    raise Http404

@session_required1
def update_status(request,id):
    update=bookings.objects.get(id=id)
    if request.method=="POST":
        update.BookingStatus=request.POST.get('status')
        update.save()
        return redirect('admin_dashboard')
    return render(request,'updatebookings.html',{'update':update})

@session_required1
def accepted_bookings(request):
    cursor2=connection.cursor()
    cursor2.execute("select * from bikerentzapp_bookings where bikerentzapp_bookings.BookingStatus='Accepted'")
    results2=cursor2.fetchall()
    return render(request,'acceptedbookings.html',{'viewbookings':results2})

@session_required1
def waiting_bookings(request):
    cursor3=connection.cursor()
    cursor3.execute("select * from bikerentzapp_bookings where bikerentzapp_bookings.BookingStatus='Waiting'")
    results3=cursor3.fetchall()
    return render(request,'waitingbookings.html',{'viewbookings':results3})

@session_required1
def rejected_bookings(request):
    cursor4=connection.cursor()
    cursor4.execute("select * from bikerentzapp_bookings where bikerentzapp_bookings.BookingStatus='Rejected'")
    results4=cursor4.fetchall()
    return render(request,'rejectedbookings.html',{'viewbookings':results4})

@session_required1
def completed_bookings(request):
    cursor5=connection.cursor()
    cursor5.execute("select * from bikerentzapp_bookings where bikerentzapp_bookings.BookingStatus='Completed'")
    results5=cursor5.fetchall()
    return render(request,'completedbookings.html',{'viewbookings':results5})

@session_required1
def admin_feedbacks(request):
    feedback=feedbacks.objects.all()
    return render(request,'feedbacks.html',{'get_feedback':feedback})

@session_required1
def update_feedback(request,id):
    edit_ef=feedbacks.objects.get(id=id)
    if request.method == "POST":
        edit_ef.AdminResponse = request.POST.get('admin-response')
        edit_ef.save()
        return redirect('feedbacks')
    return render(request,'editfeedback.html',{'updatefeedback':edit_ef})

@session_required1
def admin_profile(request):
    admin_data=admin.objects.all()
    return render(request,'adminprofile.html',{'admindata':admin_data})

@session_required1
def edit_adminprofile(request,id):
    edit_data=admin.objects.get(id=id)
    if request.method=="POST":
        edit_data.Contact = request.POST.get('admincontact')
        edit_data.Email = request.POST.get('adminemail')
        edit_data.Password = request.POST.get('adminpassword')
        return redirect('admin_profile')
    return render(request,'editadminprofile.html',{'editdata':edit_data})

def logout_admin(request):
    request.session.flush()
    return redirect('home')

# from bikerentzapp.models import vehiclebrand
# @session_required1
# def all_bookings(request):
#     if request.method=="POST":
#         if request.POST.get('brand'):
#             vbrand=vehiclebrand()
#             vbrand.brand=request.POST.get('brand')
#             vbrand.save()
#             messages.success(request,'Success')
#             return render(request,'addbikes.html')
#     else:
#             return render(request,'newbookings.html')