from django.db import models
import os

# Create your models here.
class user(models.Model):
    Username=models.CharField(max_length=50,unique=True)
    Name=models.CharField(max_length=50,null=True,blank=True)
    Contact=models.BigIntegerField(unique=True)
    DOB=models.DateField()
    Age=models.IntegerField()
    Address=models.CharField(max_length=50)
    Email=models.EmailField(max_length=30,unique=True)
    Password=models.CharField(max_length=30)

class admin(models.Model):
    Username=models.CharField(max_length=15,unique=True)
    Name=models.CharField(max_length=30,null=True,blank=True)
    Contact=models.BigIntegerField(null=True,blank=True,unique=True)
    Email=models.EmailField(max_length=50,blank=True,null=True,unique=True)
    Password=models.CharField(max_length=35)

def imagepath(request,imagename):
    return os.path.join('static/uploads/',imagename)

class bikes(models.Model):
    Vehiclename=models.CharField(max_length=30,null=True,blank=True)
    Vehiclebrand=models.CharField(max_length=30)
    Vehicletype=models.CharField(max_length=30,null=True,blank=True)
    Modelyear=models.IntegerField()
    Vehiclenumber=models.CharField(max_length=30,unique=True,null=True,blank=True)
    Insuranceupto=models.DateField()
    AmountPerDay=models.CharField(max_length=10,null=True,blank=True)
    VehicleDescription=models.CharField(max_length=100)
    Vehicleimage=models.ImageField(upload_to=imagepath,null=True,blank=True)

def filepath(request,filename):
    return os.path.join('static/files/',filename)

class bookings(models.Model):
    CustomerUsername=models.CharField(max_length=30)
    CustomerName=models.CharField(max_length=30,null=True,blank=True)
    CustomerContact=models.BigIntegerField()
    CustomerAddress=models.CharField(max_length=100)
    CustomerEmail=models.EmailField(max_length=50)
    RentalDate=models.DateField(null=True,blank=True)
    BikeName=models.CharField(max_length=20,null=True,blank=True)
    Rent=models.CharField(max_length=20)
    Idproof=models.CharField(max_length=30)
    Idfile=models.FileField(upload_to=filepath,null=True,blank=True)
    BookingStatus=models.CharField(max_length=30,null=True,blank=True)

class TimeStamp(models.Model):
    PostingDate=models.DateField(auto_now_add=True,null=True,blank=True)
    class Meta:
        abstract = True

class feedbacks(TimeStamp):
    Username=models.CharField(max_length=30)
    Bikename=models.CharField(max_length=30,null=True,blank=True)
    Feedback=models.CharField(max_length=500)
    AdminResponse=models.CharField(max_length=500,null=True,blank=True)

# class vehiclebrand(models.Model):
#     brand=models.CharField(max_length=20)
#     class Meta:
#         db_table="vehicle"
