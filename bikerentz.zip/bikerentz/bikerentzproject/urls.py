"""bikerentzproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from bikerentzapp import views
from django.conf import settings
from django.conf.urls.static import static
from django.conf.urls import url
from django.views.static import serve

urlpatterns = [
    path('admin/', admin.site.urls),
    # path('',views.index,name='home'),
    path('',views.admin_login,name='home'),
    path('register/',views.register,name='register'),
    path('login/',views.login,name='login'),
    path('user/userdashboard/',views.user_home,name='dashboard'),
    path('user/viewbikes/',views.view_bikes,name='view_bikes'),
    path('user/bookbikes/<int:id>',views.book_bikes,name='book_bikes'),
    path('user/mybookings/',views.my_bookings,name='my_bookings'),
    path('user/deletebooking/<int:id>',views.delete_booking,name='delete_booking'),
    path('user/postfeedback/',views.post_feedback,name='post_feedback'),
    path('user/myfeedbacks/',views.my_feedback,name='my_feedback'),
    path('user/profile/',views.user_profile,name='user_profile'),
    path('user/editprofile/<int:id>',views.edit_userprofile,name='edit_userprofile'),
    path('logout/',views.logout_user,name='logout_user'),




    path('bikerentzadmin/admindashboard/',views.admin_home,name='admin_dashboard'),
    path('bikerentzadmin/users/',views.all_users,name='all_users'),
    path('bikerentzadmin/deleteuser/<int:id>',views.delete_user,name='delete_user'),
    path('bikerentzadmin/addbikes/',views.add_bikes,name='add_bikes'),
    path('bikerentzadmin/managebikes/',views.manage_bikes,name='manage_bikes'),
    path('bikerentzadmin/editbikes/<int:id>',views.edit_bikes,name='edit_bikes'),
    path('bikerentzadmin/allbikes/<int:id>',views.delete_bikes,name='delete_bikes'),
    path('bikerentzadmin/newbookings/',views.all_bookings,name='new_bookings'),
    url(r'^download/(?P<path>.*)$',serve,{'document_root':settings.MEDIA_ROOT}),
    path('bikerentzadmin/updatestatus/<int:id>',views.update_status,name='update_status'),
    path('bikerentzadmin/acceptedbookings',views.accepted_bookings,name='accepted_bookings'),
    path('bikerentzadmin/waitingbookings',views.waiting_bookings,name='waiting_bookings'),
    path('bikerentzadmin/rejectedbookings',views.rejected_bookings,name='rejected_bookings'),
    path('bikerentzadmin/completedbookings',views.completed_bookings,name='completed_bookings'),
    path('bikerentzadmin/feedbacks/',views.admin_feedbacks,name='feedbacks'),
    path('bikerentzadmin/updatefeedback/<int:id>',views.update_feedback,name='update_feedback'),
    path('bikerentzadmin/profile/',views.admin_profile,name='admin_profile'),
    path('bikerentzadmin/editprofile/<int:id>',views.edit_adminprofile,name='admin_editprofile'),
    path('logout/',views.logout_admin,name='logout_admin')
    # path('admin_home/all_bookings/',views.all_bookings,name='all_bookings')


]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

